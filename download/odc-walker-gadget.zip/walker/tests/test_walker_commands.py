"""Host test: the walker command contract stays consistent.

Checks that the five walker.* commands are:
  1. advertised in integration/register.snippet (add_command),
  2. dispatched in integration/dispatch.snippet (strcmp branches),
  3. implemented as walker_cmd_* handlers declared in main/walker_commands.h,
all gated on CONFIG_ODC_WALKER.

Run: python3 tests/test_walker_commands.py
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
COMMANDS = ["walker.walk", "walker.stop", "walker.turn", "walker.status", "walker.reset"]


def read(p):
    return (ROOT / p).read_text()


def main():
    failures = []

    register = read("integration/register.snippet")
    dispatch = read("integration/dispatch.snippet")
    header = read("main/walker_commands.h")
    impl = read("main/walker_commands.c")

    advertised = set(re.findall(r'add_command\(commands,\s*"([^"]+)"', register))
    dispatched = set(re.findall(r'strcmp\(command,\s*"([^"]+)"\)', dispatch))
    declared = set(re.findall(r"walker_cmd_(\w+)\(", header))

    for cmd in COMMANDS:
        if cmd not in advertised:
            failures.append(f"{cmd} not advertised in register.snippet")
        if cmd not in dispatched:
            failures.append(f"{cmd} not dispatched in dispatch.snippet")
        short = cmd.split(".")[1]
        if short not in declared:
            failures.append(f"walker_cmd_{short} not declared in walker_commands.h")
        if f"cJSON *walker_cmd_{short}(" not in impl:
            failures.append(f"walker_cmd_{short} not implemented in walker_commands.c")

    # No extras: every advertised walker.* command must be one of the five.
    for cmd in advertised:
        if cmd.startswith("walker.") and cmd not in COMMANDS:
            failures.append(f"unexpected advertised command: {cmd}")

    # Both integration points gated on the same Kconfig option.
    for name, text in [("register.snippet", register), ("dispatch.snippet", dispatch)]:
        if "#if CONFIG_ODC_WALKER" not in text:
            failures.append(f"{name} not gated on CONFIG_ODC_WALKER")

    # Async contract: walker.walk must answer via noise_ctrl_send_command_result.
    if "noise_ctrl_send_command_result" not in impl:
        failures.append("walker.walk does not answer asynchronously")

    if failures:
        print("FAIL:")
        for f in failures:
            print(f"  - {f}")
        return 1
    print(f"ok: {len(COMMANDS)} walker commands, contract consistent")
    return 0


if __name__ == "__main__":
    sys.exit(main())
