# ODC Walker × Muse Gadgets SDK

Makes the One Dollar Computer walker a **Muse Gadget**: the Muse assistant
calls the walker's commands by name (`link.register` / `link.invoke`).

Based on the Meta [muse-gadget-sdk](https://github.com/facebookincubator/muse-gadget-sdk)
(Apache 2.0), ESP32 target. A pristine copy of the SDK (shallow clone) lives in
`../sdk/` for reference — this folder only adds the walker.

## Commands

| Command | What it does |
|---|---|
| `walker.walk` | Learned gait (the trained word "walk"). Optional `duration_s` (0–600, 0 = until stop). Async. |
| `walker.stop` | Stop immediately, servos to neutral. |
| `walker.turn` | Turn in place. Required `direction` ("left"/"right"), optional `degrees` (15–360, default 90). |
| `walker.status` | Telemetry: `upZ`, `tiltDeg`, `state`, `walking` — the same numbers the ODC train mode interprets. |
| `walker.reset` | Back to the editor-saved standing pose. Never touches learned words or training data. |

## Files

- `main/walker_commands.h` / `main/walker_commands.c` — the five handlers.
  Follows the SDK's "Adding a command" contract: validate params yourself,
  never block the Noise task (`walker.walk` answers asynchronously via
  `noise_ctrl_send_command_result()`), keep `link.register` small.
- `integration/` — four snippets to paste into the SDK tree:
  - `Kconfig.snippet` → `sdk/esp32/main/Kconfig.projbuild`
  - `CMakeLists.snippet` → `sdk/esp32/main/CMakeLists.txt`
  - `register.snippet` → `build_register_json()` in `sdk/esp32/main/noise_control.cpp`
  - `dispatch.snippet` → `on_ws_command()` in `sdk/esp32/main/app.c`
- `tests/test_walker_commands.py` — host test: advertised == dispatched ==
  implemented, all gated on `CONFIG_ODC_WALKER`.

## Bring-up (on your machine — sandbox can't flash)

1. ESP-IDF v5.x, `idf.py`. Board: any ESP32-S3/C5 **with PSRAM** (tunnel needs it).
2. Adjust `WALKER_SERVO_GPIO_*` in `main/walker_commands.c` to your wiring.
3. Paste the four integration snippets, enable `ODC_WALKER` in menuconfig.
4. SDK token: `gadgets.muse.ai` → Settings → SDK tokens (your login).
5. `idf.py flash monitor`; pair in the Muse app: Settings → Devices → Developer mode.
6. The gadget shows up as `MuseGadget-XXXXXX` — Muse can now call the five commands.

## Only you can do

- Generate the SDK token (your Muse login).
- Reserve the free Home Link dongle (5,000 units, first-come, ships October) —
  note: not reflashable, reference device only.
- Flash over USB serial.
