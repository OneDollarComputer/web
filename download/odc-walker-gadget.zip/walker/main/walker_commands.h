// ODC Walker gadget commands for the Meta Muse Gadgets SDK (ESP32).
//
// Implements the 5 walker commands following the SDK's "Adding a command"
// contract (esp32/AGENTS.md):
//   - advertise in build_register_json()  -> see integration/register.snippet
//   - handle in on_ws_command()           -> see integration/dispatch.snippet
//   - gate on CONFIG_ODC_WALKER           -> see integration/Kconfig.snippet
//   - never block the Noise task: walker.walk runs in its own FreeRTOS task
//     and answers asynchronously via noise_ctrl_send_command_result().
//
// Hardware: 4x SG90 servos (±90°) on LEDC PWM. GPIO pins are board-specific —
// adjust WALKER_SERVO_GPIO_* below to your board.

#pragma once

#include "cJSON.h"
#include "noise_control.h"  // noise_ctrl_session_generation_t

#ifdef __cplusplus
extern "C" {
#endif

// Call once at startup (after LEDC is available).
void walker_init(void);

// Feed live pose telemetry (e.g. from an IMU task). walker.status reports it.
void walker_report_pose(float up_z, float tilt_deg, const char *state);

// Command handlers. Each returns a cJSON result object owned by the caller:
// {"ok": true, "payload": {...}}, an error object, or {"_async": true}.
cJSON *walker_cmd_walk(cJSON *params, const char *request_id,
                       noise_ctrl_session_generation_t session_generation);
cJSON *walker_cmd_stop(cJSON *params);
cJSON *walker_cmd_turn(cJSON *params);
cJSON *walker_cmd_status(cJSON *params);
cJSON *walker_cmd_reset(cJSON *params);

#ifdef __cplusplus
}
#endif
