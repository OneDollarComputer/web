// ODC Walker gadget commands — see walker_commands.h for the contract.
//
// Servo model: SG90, ±90° mapped to 50 Hz PWM, 1000–2000 µs pulse.
// The gait itself is intentionally simple (alternating leg pairs); replace
// walker_gait_step() with the learned gait from the ODC train mode.

#include "walker_commands.h"

#include <math.h>
#include <string.h>

#include "driver/ledc.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "odc_walker";

// ---- Board-specific servo wiring: ADJUST TO YOUR BOARD ----
#define WALKER_SERVO_GPIO_0  25  // front-left hip
#define WALKER_SERVO_GPIO_1  26  // front-right hip
#define WALKER_SERVO_GPIO_2  27  // rear-left hip
#define WALKER_SERVO_GPIO_3  14  // rear-right hip
#define WALKER_SERVO_COUNT   4
#define WALKER_SERVO_MIN_DEG -90.0f
#define WALKER_SERVO_MAX_DEG 90.0f

static const int s_servo_gpios[WALKER_SERVO_COUNT] = {
    WALKER_SERVO_GPIO_0, WALKER_SERVO_GPIO_1,
    WALKER_SERVO_GPIO_2, WALKER_SERVO_GPIO_3,
};

// ---- Walker state ----
static volatile bool s_walking = false;
static float s_up_z = 1.0f;
static float s_tilt_deg = 0.0f;
static char s_state[24] = "idle";
static SemaphoreHandle_t s_state_lock = NULL;

void walker_report_pose(float up_z, float tilt_deg, const char *state) {
    if (xSemaphoreTake(s_state_lock, pdMS_TO_TICKS(50)) != pdTRUE) return;
    s_up_z = up_z;
    s_tilt_deg = tilt_deg;
    strncpy(s_state, state ? state : "unknown", sizeof(s_state) - 1);
    s_state[sizeof(s_state) - 1] = '\0';
    xSemaphoreGive(s_state_lock);
}

// ---- Servo HAL (LEDC, 50 Hz) ----
static void servo_write_deg(int idx, float deg) {
    if (idx < 0 || idx >= WALKER_SERVO_COUNT) return;
    if (deg < WALKER_SERVO_MIN_DEG) deg = WALKER_SERVO_MIN_DEG;
    if (deg > WALKER_SERVO_MAX_DEG) deg = WALKER_SERVO_MAX_DEG;
    // -90° -> 1000 µs, +90° -> 2000 µs, 14-bit duty at 50 Hz.
    uint32_t us = (uint32_t)(1500.0f + (deg / 90.0f) * 500.0f);
    uint32_t duty = (us * 16383) / 20000;
    ledc_set_duty(LEDC_LOW_SPEED_MODE, (ledc_channel_t)idx, duty);
    ledc_update_duty(LEDC_LOW_SPEED_MODE, (ledc_channel_t)idx);
}

void walker_init(void) {
    s_state_lock = xSemaphoreCreateMutex();
    ledc_timer_config_t timer = {
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .duty_resolution = LEDC_TIMER_14_BIT,
        .timer_num = LEDC_TIMER_0,
        .freq_hz = 50,
        .clk_cfg = LEDC_AUTO_CLK,
    };
    ledc_timer_config(&timer);
    for (int i = 0; i < WALKER_SERVO_COUNT; i++) {
        ledc_channel_config_t ch = {
            .gpio_num = s_servo_gpios[i],
            .speed_mode = LEDC_LOW_SPEED_MODE,
            .channel = (ledc_channel_t)i,
            .timer_sel = LEDC_TIMER_0,
            .duty = 0,
            .hpoint = 0,
        };
        ledc_channel_config(&ch);
        servo_write_deg(i, 0.0f);  // neutral = editor-saved standing pose
    }
    ESP_LOGI(TAG, "walker init: %d servos on LEDC", WALKER_SERVO_COUNT);
}

// ---- Result helpers (mirror app.c's command_error) ----
static cJSON *walker_error(const char *code, const char *message) {
    cJSON *result = cJSON_CreateObject();
    cJSON_AddBoolToObject(result, "ok", false);
    cJSON *error = cJSON_CreateObject();
    cJSON_AddStringToObject(error, "code", code);
    cJSON_AddStringToObject(error, "message", message);
    cJSON_AddItemToObject(result, "error", error);
    return result;
}

static cJSON *walker_ok(cJSON *payload) {
    cJSON *result = cJSON_CreateObject();
    cJSON_AddBoolToObject(result, "ok", true);
    cJSON_AddItemToObject(result, "payload", payload ? payload : cJSON_CreateObject());
    return result;
}

static cJSON *walker_async(void) {
    cJSON *result = cJSON_CreateObject();
    cJSON_AddBoolToObject(result, "_async", true);
    return result;
}

// ---- Gait ----

// One gait cycle: alternate diagonal pairs. Replace with the learned gait.
static void walker_gait_step(int phase) {
    float a = (phase % 2 == 0) ? 25.0f : -25.0f;
    servo_write_deg(0, a);
    servo_write_deg(3, a);
    servo_write_deg(1, -a);
    servo_write_deg(2, -a);
}

typedef struct {
    noise_ctrl_session_generation_t session_generation;
    char request_id[64];
    float duration_s;  // 0 = walk until walker.stop
} walk_task_args_t;

static void walk_task(void *arg) {
    walk_task_args_t *args = (walk_task_args_t *)arg;
    const TickType_t step_ticks = pdMS_TO_TICKS(400);
    TickType_t start = xTaskGetTickCount();
    int phase = 0;
    ESP_LOGI(TAG, "walk start (duration %.1fs)", args->duration_s);
    while (s_walking) {
        walker_gait_step(phase++);
        if (args->duration_s > 0 &&
            (xTaskGetTickCount() - start) >= pdMS_TO_TICKS((uint32_t)(args->duration_s * 1000))) {
            break;
        }
        vTaskDelay(step_ticks);
    }
    s_walking = false;
    for (int i = 0; i < WALKER_SERVO_COUNT; i++) servo_write_deg(i, 0.0f);

    cJSON *payload = cJSON_CreateObject();
    cJSON_AddStringToObject(payload, "stopped", "completed");
    cJSON_AddNumberToObject(payload, "steps", phase);
    noise_ctrl_send_command_result(args->session_generation, args->request_id,
                                   walker_ok(payload));
    free(args);
    vTaskDelete(NULL);
}

cJSON *walker_cmd_walk(cJSON *params, const char *request_id,
                       noise_ctrl_session_generation_t session_generation) {
    if (s_walking) return walker_error("already_walking", "walker is already walking");
    float duration_s = 0.0f;
    cJSON *d = params ? cJSON_GetObjectItem(params, "duration_s") : NULL;
    if (cJSON_IsNumber(d)) {
        if (d->valuedouble < 0 || d->valuedouble > 600)
            return walker_error("bad_param", "duration_s must be 0..600");
        duration_s = (float)d->valuedouble;
    }
    walk_task_args_t *args = calloc(1, sizeof(*args));
    if (!args) return walker_error("out_of_memory", "failed to allocate walk task");
    args->session_generation = session_generation;
    strncpy(args->request_id, request_id ? request_id : "", sizeof(args->request_id) - 1);
    args->duration_s = duration_s;
    s_walking = true;
    if (xTaskCreate(walk_task, "walker_walk", 4096, args, 5, NULL) != pdPASS) {
        s_walking = false;
        free(args);
        return walker_error("out_of_memory", "failed to start walk task");
    }
    return walker_async();  // result arrives via noise_ctrl_send_command_result()
}

cJSON *walker_cmd_stop(cJSON *params) {
    (void)params;
    s_walking = false;  // walk_task exits its loop and reports completion
    cJSON *payload = cJSON_CreateObject();
    cJSON_AddBoolToObject(payload, "stopping", true);
    return walker_ok(payload);
}

cJSON *walker_cmd_turn(cJSON *params) {
    cJSON *dir = params ? cJSON_GetObjectItem(params, "direction") : NULL;
    if (!cJSON_IsString(dir) || !dir->valuestring)
        return walker_error("missing_param", "direction is required");
    int sign;
    if (strcmp(dir->valuestring, "left") == 0) sign = 1;
    else if (strcmp(dir->valuestring, "right") == 0) sign = -1;
    else return walker_error("bad_param", "direction must be \"left\" or \"right\"");
    float degrees = 90.0f;
    cJSON *deg = params ? cJSON_GetObjectItem(params, "degrees") : NULL;
    if (cJSON_IsNumber(deg)) {
        if (deg->valuedouble < 15 || deg->valuedouble > 360)
            return walker_error("bad_param", "degrees must be 15..360");
        degrees = (float)deg->valuedouble;
    }
    // Differential turn: bias one side. Scales with requested degrees.
    float bias = sign * fminf(degrees / 90.0f, 2.0f) * 20.0f;
    servo_write_deg(0, bias);
    servo_write_deg(2, bias);
    servo_write_deg(1, -bias);
    servo_write_deg(3, -bias);
    vTaskDelay(pdMS_TO_TICKS(600));
    for (int i = 0; i < WALKER_SERVO_COUNT; i++) servo_write_deg(i, 0.0f);
    cJSON *payload = cJSON_CreateObject();
    cJSON_AddStringToObject(payload, "direction", dir->valuestring);
    cJSON_AddNumberToObject(payload, "degrees", degrees);
    return walker_ok(payload);
}

cJSON *walker_cmd_status(cJSON *params) {
    (void)params;
    cJSON *payload = cJSON_CreateObject();
    if (xSemaphoreTake(s_state_lock, pdMS_TO_TICKS(50)) == pdTRUE) {
        cJSON_AddNumberToObject(payload, "upZ", s_up_z);
        cJSON_AddNumberToObject(payload, "tiltDeg", s_tilt_deg);
        cJSON_AddStringToObject(payload, "state", s_state);
        xSemaphoreGive(s_state_lock);
    }
    cJSON_AddBoolToObject(payload, "walking", s_walking);
    return walker_ok(payload);
}

cJSON *walker_cmd_reset(cJSON *params) {
    (void)params;
    s_walking = false;
    vTaskDelay(pdMS_TO_TICKS(50));  // let walk_task exit if running
    // Editor-saved standing pose = neutral. (A saved pose table can replace
    // these constants once the editor exports per-joint angles.)
    for (int i = 0; i < WALKER_SERVO_COUNT; i++) servo_write_deg(i, 0.0f);
    walker_report_pose(1.0f, 0.0f, "idle");
    cJSON *payload = cJSON_CreateObject();
    cJSON_AddStringToObject(payload, "pose", "editor-saved standing pose");
    return walker_ok(payload);
}
